﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;

namespace Link_Scanner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private bool IsRobloxPrivateServerLinkValid(string link)
        {
            if (!link.StartsWith("https://www.roblox.com/games/"))
            {
                return false;
            }
            if (!link.Contains("?privateServerLinkCode="))
            {
                return false;
            }
            string linkCode = link.Substring(link.IndexOf("?privateServerLinkCode=") + "?privateServerLinkCode=".Length);
            if (string.IsNullOrEmpty(linkCode))
            {
                return false;
            }
            Guid guid;
            if (!Guid.TryParse(linkCode, out guid))
            {
                return false;
            }
            return true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string robloxLink = textBox1.Text;
            bool isValidLink = IsRobloxPrivateServerLinkValid(robloxLink);
            if (isValidLink)
            {
                label1.Text = "Valid";
                label1.ForeColor= Color.Green;
            }
            else
            {
                label1.Text = "Invalid";
                label1.ForeColor = Color.Red;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            
        }
    }
 }